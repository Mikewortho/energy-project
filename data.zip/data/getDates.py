import pandas as pd
import csv
df = pd.DataFrame(pd.date_range("2001-01-01", "2018-08-11", freq="H", tz = 'UTC')).to_csv("temp.csv", header=["TimeAndDate"])
